#ifndef __MAIN_H__
#define __MAIN_H__
#include"gurobi_c++.h"
#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<bitset>
#include<set>
#include<algorithm>
#include<map>
#include<utility>
#include<stdlib.h>
#include<iterator>
#include<math.h>
#include<gmpxx.h>
#include<thread>
using namespace std;
#endif
