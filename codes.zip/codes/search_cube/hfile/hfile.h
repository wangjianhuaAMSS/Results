#ifndef __HFILE_H__
#define __HFILE_H__
#include "main.h"
#include "vector_degree.h"




//#define N 542 69250
//#define N 80
//#define M 80


#define MAX_V 80

#define R0 200
#define BOUND 200

#define CBBOUND 50000
#define TIMELIMIT 300

#define Round 850

using namespace std;


/*template <size_t T> struct cmpBitset {
	bool operator()(const bitset<T>& a, const bitset<T>& b) const {
		for (int i = T - 1; i >= 0; i--) {
			if (a[i] < b[i])
				return true;
			else if (a[i] > b[i])
				return false;
		}
		return false;
	}
};*/

template <size_t T> void print_bitset_to_hex(bitset<T> b) {
	string str = b.to_string();
	if (T % 32 != 0) {
		bitset<32> tmp(str, 0, T%32);
        cout << hex << tmp.to_ulong() << " ";
	}
	int i = T % 32;
    while (i < T) {
        bitset<32> tmp(str, i, 32);
        cout << hex << tmp.to_ulong() << " ";
		i = i + 32;
    }
    cout << dec << endl;
}





void trivium_vector_degree_estimation(int8_t *zout, int round0, bitset<80> vd_index, bitset<80> v_degree, bitset<80> v_0, bitset<80> k_degree, bitset<80> k_0, int output_mode);
void trivium_vector_degree_estimation_for_some_rounds_states(bitset<80> vd_index, bitset<80> v_degree, bitset<80> v_0, bitset<80> k_degree, bitset<80> k_0, vector<vector<int8_t>>& states_degree, vector<int> rounds);

void search_of_cubes(int bn, int an, int bd, int round0, int n, vector<int> &choose_index, ofstream *fcube);
void set_vector_degree_index(bitset<80>& vd_index, bitset<80> v_degree, bitset<80> v_0, bitset<80> k_degree, bitset<80> k_0, int Convdn, int round0);
void milp_seach_cube(bitset<80> init_cube, int cube_size_l, int cube_size_u, bitset<80> init_vd_index, vector<bitset<80>> constrs, int deg_con, int threadNumber, int output_round, vector<bitset<80>>* out_cube, ofstream *cf);
void read_constrs_from_file(vector<bitset<80>> &constrs, ifstream *cf);
void bitset_to_16_print(bitset<80> key);

void test_ge768();
int generate_random_cubes1(bitset<80> &cube, int init_cube_num);
bool generate_random_cubes2(bitset<80> &cube, int max_add_num, int init_cube_num);
int find_max_round(int8_t *zout, int len, int8_t deg);
void read_middle_set(ifstream *ifs, ofstream *ofds, bitset<80> cube, int num);

#endif
