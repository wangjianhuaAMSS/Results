#include "vector_degree.h"


