#include "main.h"

#ifndef _VECTOR_DEGREE_H_
#define _VECTOR_DEGREE_H_
#define MAXVLEN 40 //maximal size of the set of vector degree

template<typename T>
class Vdeg{
private: vector<T> v;
public: 
	Vdeg();
	Vdeg(int n);
	Vdeg<T> &operator =(const Vdeg<T> &vd1);
	Vdeg<T> &operator +=(const Vdeg<T> vd1);
	Vdeg<T> &operator *=(const Vdeg<T> vd1);
	T & operator [](size_t k);
	const size_t size() const;
	friend ostream & operator << (ostream &out, Vdeg &vd){
		for (size_t i = 0; i < vd.size(); i++) 
			out << (signed)vd[i] << " ";
		out << endl;
		return(out);
	}
};

template<typename T>
Vdeg<T>::Vdeg() {
}

template<typename T>
Vdeg<T>::Vdeg(int n) {
	v.clear();
	for (int i = 0; i < n; i++) {
		v.push_back(-128);
	}
}


template<typename T>
Vdeg<T> & Vdeg<T>:: operator =(const Vdeg<T> & vd1) {
	v.clear();
	v.insert(v.begin(), vd1.v.begin(), vd1.v.end());
	return(*this);
}

template<typename T>
Vdeg<T> & Vdeg<T>:: operator +=(const Vdeg<T> vd1) {
	assert(v.size() == vd1.v.size());
	for (int i = 0; i < vd1.v.size(); i++) {
		v[i] = max(vd1.v[i], v[i]);
	}
	return(*this);
}

template<typename T>
Vdeg<T> & Vdeg<T>:: operator *=(const Vdeg<T> vd1) {
	assert(v.size() == vd1.v.size());
	vector<T> tmp(v.size(), -128);
	for (int i = 0; i < vd1.v.size(); i++) {
		if (vd1.v[i] >= 0) {
			for (int j = 0; j < v.size(); j++) {
				if (v[j] >= 0) {
					T d = vd1.v[i] + v[j];
					tmp[i | j] = max(tmp[i | j], d);
				}
			}
		}
	}
	v = move(tmp);
	return(*this);
}

template<typename T>
T & Vdeg<T> :: operator [](size_t k) {
	assert(k < v.size());
	return(v[k]);
}

template<typename T> 
const size_t Vdeg<T> :: size() const{
	return(v.size());
}



/*template<typename T>
istream & operator >> (istream &in, Vdeg<T> &vd) {
	T d;
	in >> d;
	vd.v.push_back(d);
	char c;
	in >> c;
	while (c != ' ') {
		in >> d;
		vd.v.push_back(d);
		in >> c;
	}
	return(in);
}*/

template<typename T>
Vdeg<T> operator +(const Vdeg<T> vd1, const Vdeg<T> vd2) {
	assert(vd1.size() == vd2.size());
	Vdeg<T> vd = vd1;
	vd += vd2;
	return(vd);
}

template<typename T> 
Vdeg<T> operator *(const Vdeg<T> vd1, const Vdeg<T> vd2) {
	Vdeg<T> vd = vd1;
	vd *= vd2;
	return(vd);
}

template<typename T>
Vdeg<T> min_vector_degree(Vdeg<T> vd1, Vdeg<T> vd2) {
	assert(vd1.size() == vd2.size());
	Vdeg<T> vd(vd1.size());
	for (int i = 0; i < vd1.size(); i++) {
		if (floor(vd1[i]) == floor(vd2[i]))
			vd[i] = max(vd1[i], vd2[i]);
		else
			vd[i] = min(vd1[i], vd2[i]);
	}
	return(vd);
}

template<typename T>
T compute_degree(Vdeg<T> vd) {
	T d = -128;
	for (int i = 0; i < vd.size(); i++) {
		bitset<MAXVLEN> b(i);
		T dd = vd[i] + b.count();
		d = max(d, dd);
	}
	return(d);
} 

template<typename T>
T deterministic_degree(Vdeg<T> vd) {
	T d = -128;
	int i = vd.size() - 1;
	bitset<MAXVLEN> b(i);
	T dd = vd[i] + b.count();
	d = max(d, dd);
	return(d);
}

template<typename T>
T adjusted_degree(Vdeg<T> vd, T max_degree) {
	T d = -128;
	bitset< MAXVLEN> bm(vd.size() - 1);
	T vds = bm.count();
	for (size_t i = 0; i < vd.size(); i++) {
		bitset<MAXVLEN> b(i);
		T dd;
		if (vd[i] > max_degree - vds) {
			dd = max_degree - vds + b.count();
		}
		else {
			dd = vd[i] + b.count();
		}
		d = max(d, dd);
	}
	return(d);
}


#endif
