#include "../../hfile/hfile.h"
#include "estimation_of_trivium_vector_degree.h"
#define M 80
template<typename T>
class Milp_search_cube : public GRBCallback
{
public:
	int output_mode;
	bitset<M> init_vd_index;
	T deg_con;
	int output_round;
	vector<GRBVar> cube_var;
	ofstream *cf;
	ofstream *resultf;
public:
	Milp_search_cube(int xoutput_mode, bitset<M> xinit_vd_index, T xdeg_con, int xoutput_round, vector<GRBVar> xcube_var, ofstream *xcf, ofstream *xresultf) {
		output_mode = xoutput_mode;
		init_vd_index = xinit_vd_index;
		deg_con = xdeg_con;
		output_round = xoutput_round;
		cube_var = xcube_var;
		cf = xcf;
		resultf = xresultf;
	}
protected:
	void callback() {
		try {
			if (where == GRB_CB_MIPSOL) {
				//load solutions
				bitset<M> cube;
				bool issolution = false;
				
				for (int i = 0; i < M; i++) {
					if (round(getSolution(cube_var[i])) == 1) {
						cube[i] = 1;
						cout << i << " ";
					}
					else cube[i] = 0;
					
				}
				cout << endl;

				//estimate the degree of the cube
				vector<int> cube_index;
				bitset<80> vd_index, k_degree, k_0, v_0;;
				v_0 = cube;
				v_0.flip();
				vd_index = cube & init_vd_index;
				for (int i = 0; i < M; i++) {
					if ((cube[i] == 1) && (vd_index[i] == 0)) {
						cube_index.push_back(i);
					}
				}
				T cube_deg;
				cube_deg = trivium_vector_degree_estimation<T>(output_round, output_mode, vd_index, cube, v_0, k_degree, k_0);
				cout << (signed)cube_deg << endl;
				if (cube_deg < deg_con) {
					issolution = true;
				}

				//if cube_deg >= deg_con, then search of max space
				srand((int)time(NULL));
				while (cube_deg >= deg_con) {
					int k = 0;
					int in;
					bool flag = true;
					while (k < cube_index.size())
					{ // repeat cube_index.size() times
						in = rand() % ((int)cube_index.size());
						bitset<M> cube_copy;
						cube_copy = cube;
						cube_copy[cube_index[in]] = 0;
						v_0 = cube_copy;
						v_0.flip();
						cube_deg = trivium_vector_degree_estimation<T>(output_round, output_mode, vd_index, cube_copy, v_0, k_degree, k_0);
						if (cube_deg >= deg_con)
						{
							cube[cube_index[in]] = 0;
							flag = false;
							cube_index.erase(cube_index.begin() + in);
							break;
						}
						k++;
					}
					if (flag)
						break;
				}
				
 				GRBLinExpr con = 0;
				for (int i = 0; i < M; i++) {
					if (cube[i] == 1) {
						(*cf) << i << " ";
						//cout << i << " ";
						con += cube_var[i];
					}
				}
				(*cf) << endl;
				//cout << endl; 
				addLazy(con <= cube.count() - 1);
				if (issolution) {
					for (int i = 0; i < M; i++) {
						if (cube[i] == 1) {
							(*resultf) << i << " ";
							//cout << i << " ";
						}
					}
					(*resultf) <<  signed(cube_deg) << endl;
				}
				
				
			}
			else if (where == GRB_CB_MESSAGE) {
				// Message callback
				string msg = getStringInfo(GRB_CB_MSG_STRING);
				cout << msg << flush;
			}
		}
		catch (GRBException e) {
			cerr << "Error number: " << e.getErrorCode() << endl;
			cerr << e.getMessage() << endl;
		}
		catch (...) {
			cout << "Error during callback" << endl;
		}
	}
};

template<typename T>
void triuvium_milp_seach_cube(bitset<M> init_cube, int output_mode, int cube_size_l, int cube_size_u, bitset<M> init_vd_index, vector<bitset<M>> constrs, T deg_con, int threadNumber,  int output_round, ofstream * cf, ofstream * resultf) {
	try {
		GRBEnv env = GRBEnv();

		env.set(GRB_IntParam_LogToConsole, 0);
		env.set(GRB_IntParam_Threads, threadNumber);
		env.set(GRB_IntParam_MIPFocus, 3);
		env.set(GRB_StringParam_LogFile, "log_search_cube.txt");


		env.set(GRB_IntParam_PoolSearchMode, 2);
		env.set(GRB_IntParam_PoolSolutions, 20000000);
		env.set(GRB_DoubleParam_PoolGap, GRB_INFINITY);
		env.set(GRB_IntParam_LazyConstraints, 1);

		GRBModel model = GRBModel(env);
		vector<GRBVar> cube_var(M);
		
		for (int i = 0; i < M; i++) {
			if (init_vd_index[i] == 1)
				cout << i <<" ";
		}
		cout << endl;
		
		//add constrains
		GRBLinExpr sumv;
		for (int i = 0; i < M; i++) {
			cube_var[i] = model.addVar(0, 1, 0, GRB_BINARY);
			sumv += cube_var[i];
			if (init_cube[i] == 1) {
				model.addConstr(cube_var[i] == 1);
			}
			else if ((output_mode == 2) && (init_vd_index[i] == 1)) {
				model.addConstr(cube_var[i] == 1);
			}
		}
		model.addConstr(sumv <= cube_size_u);
		model.addConstr(sumv >= cube_size_l);

		
		auto it = constrs.begin();
		while (it != constrs.end()) {
			GRBLinExpr con = 0;
			int ct = 0;
			for (int i = 0; i < M; i++) {
				if ((*it)[i] == 1) {
					con += cube_var[i];
					ct++;
				}
			}
			model.addConstr(con <= ct - 1);
			it++;
		}


		model.update();
		Milp_search_cube cb = Milp_search_cube<T>(output_mode, init_vd_index, deg_con, output_round, cube_var, cf, resultf);
		model.setCallback(&cb);
		model.optimize();
	}
	catch (GRBException e) {
		cerr << "Error code = " << e.getErrorCode() << endl;
		cerr << e.getMessage() << endl;
	}
	catch (...) {
		cerr << "Exception during optimization" << endl;
	}
}


void thread_f(int tin, vector<bitset<M>> vvd, int threadNumber, int output_round)
{
	string findex;
	int output_mode = 2;
	bitset<M> init_cube;
	
	for (int i = 0; i < M; i++) {
		if (vvd[tin][i] == 1)
			findex += (to_string(i) + "-");
	}
	int cube_size_l = 41;
	int cube_size_u = 45;
	vector<bitset<M>> constrs, vd0constrs;
	int deg_con = 46;
	ofstream cf, resultf;
	string cfname = "constrs/constrs/cube_constr" + findex + ".txt";
	string solfname = "result/result/cube_result" + findex + ".txt";
	string vd0cfname;
	cf.open(cfname.c_str(), ios::app);
	resultf.open(solfname.c_str(), ios::app);

	triuvium_milp_seach_cube<int8_t>(init_cube, output_mode, cube_size_l, cube_size_u, vvd[tin], constrs, deg_con, threadNumber,  output_round, &cf, &resultf);
	cf.close();
	resultf.close();
}


int main() {
	
	vector<bitset<M>> vvd;
	
	bitset<M> vd;
	for (int j = 0; j < 12; j++) {
		vd[j] = 1;
	}
	for (int j0 = 2; j0 < 12; j0++) {
		for (int j1 = j0 + 2; j1 < 12; j1++) {
			for (int j2= j1 + 2; j2 < 12; j2++) {
				bitset<M> vd_tmp = vd;
				vd_tmp[j0] = 0;
				vd_tmp[j1] = 0;
				vd_tmp[j2] = 0;
				vvd.push_back(vd_tmp);
			}
		}	
	}
	

	for (int i = 0; i < 1; i++) {
		vector<thread> t(24);
		for (int j = 0; j < 24; j++) {			
			t[j] = thread(thread_f, j, vvd, 1, 830);			
		}
		for (int j = 0; j < 24; j++) {
			t[j].join();
		}
	}
}
