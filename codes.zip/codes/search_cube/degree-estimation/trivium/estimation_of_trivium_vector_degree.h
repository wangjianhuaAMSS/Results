#include "../../hfile/hfile.h"

int trivium_index[3][5] = { {65, 92, 170, 90, 91}, {161, 176, 263, 174, 175}, {242, 287, 68, 285, 286} };
int trivium_length[3] = { 93, 84, 111 };

template<typename T>
void trivium_default_initial_vector_degree(vector<Vdeg<T>> &D, bitset<80> v_degree, bitset<80> k_degree, bitset<80> v_0, bitset<80> k_0, bitset<80> vd_index)
{
	for (int i = 0; i < 80; i++)
	{
		if (k_degree[i] == 1)
		{
			D[i][0] = 1;
		}
		else if (k_0[i] == 0)
		{
			D[i][0] = 0;
		}
	}

	int k = 0;
	for (int i = 93; i < 173; i++)
	{
		if (vd_index[i - 93] == 1) {
			D[i][1 << k] = 0;
			k++;
		}
		else if (v_degree[i - 93] == 1)
		{
			D[i][0] = 1;
		}
		else if (v_0[i - 93] == 0)
		{
			D[i][0] = 0;
		}
	}
	for (int i = 285; i < 288; i++)
	{
		D[i][0] = 0;
	}
	//for (int i = 0; i < 288; i++)
	//	cout << i << ":" <<  D[i] << endl;
}



template<typename T>
Vdeg<T> trivium_vector_deg_of_three_adjacent_terms(int k, vector<Vdeg<T>> D, vector<Vdeg<T>> mul_D, vector<Vdeg<T>> three_D)
{
	Vdeg<T> d1;
	Vdeg<T> m1, m2, m3;
	m1 = three_D[trivium_index[k][3] - 1] * mul_D[trivium_index[k][4]];
	m2 = three_D[trivium_index[k][4]] * mul_D[trivium_index[k][3]];
	m3 = min_vector_degree(m1, m2);
	m1 = three_D[trivium_index[k][3] - 1] * three_D[trivium_index[k][3]] * three_D[trivium_index[k][4]]; 
	d1 = min_vector_degree(m3, m1);
	return(d1);
}

template<typename T>
Vdeg<T> trivium_vector_degree_of_mul_term(int r, int k, vector<Vdeg<T>> D,  vector<Vdeg<T>> mul_D, vector<Vdeg<T>> lin_D, vector<Vdeg<T>> three_D)
{
	Vdeg<T> mul_d;
	Vdeg<T> d1, d2, d3;
	if (r < trivium_length[k])
	{
		mul_d = D[trivium_index[k][3]] * D[trivium_index[k][4]];
	}
	else
	{
		d1 = trivium_vector_deg_of_three_adjacent_terms<T>(k, D, mul_D, three_D);
		d2 = mul_D[trivium_index[k][3]] * lin_D[trivium_index[k][4]];
		d3 = lin_D[trivium_index[k][3]] * D[trivium_index[k][4]];
		mul_d = d1 + d2 + d3;
	}
	return(mul_d);
}

template<typename T>
void trivium_vector_degree_update(int r, vector<Vdeg<T>> &D, vector<Vdeg<T>> &mul_D, vector<Vdeg<T>> &lin_D, vector<Vdeg<T>> &three_D)
{
	Vdeg<T> mul_d[3], lin_d[3];
	for (int i = 0; i < 3; i++)
	{
		mul_d[i] = trivium_vector_degree_of_mul_term<T>(r, i, D, mul_D, lin_D, three_D);
		lin_d[i] = D[trivium_index[i][0]] + D[trivium_index[i][1]] + D[trivium_index[i][2]];
	}
	
	for (int i = 0; i < 2; i++)
	{
		mul_D[trivium_index[i][1]] = mul_d[i];
		lin_D[trivium_index[i][1]] = lin_d[i];
		three_D[trivium_index[i][1]] = D[trivium_index[i][4]];
		D[trivium_index[i][1]] = mul_d[i] + lin_d[i];
	}
	mul_D.pop_back();  mul_D.insert(mul_D.begin(), mul_d[2]);
	lin_D.pop_back();  lin_D.insert(lin_D.begin(), lin_d[2]);
	three_D.pop_back();  three_D.insert(three_D.begin(), D[trivium_index[2][4]]);
	D.pop_back();  D.insert(D.begin(), mul_d[2] + lin_d[2]);	
}

template<typename T>
T trivium_output_z(vector<Vdeg<T>> D, int output_mode, T max_degree)
{
	Vdeg<T> l;
	l = D[trivium_index[0][0]] + D[trivium_index[0][1]] + D[trivium_index[1][0]] + D[trivium_index[1][1]] + D[trivium_index[2][0]] + D[trivium_index[2][1]];
	assert((output_mode < 3) && (output_mode >= 0));
	if (output_mode == 0) {
		return(adjusted_degree<T>(l, max_degree));
	}
	else if (output_mode == 1) {
		return(compute_degree<T>(l));
	}
	else if (output_mode == 2) {
		return(deterministic_degree<T>(l));
	}
	return(-1);

}

template<typename T>
T trivium_vector_degree_estimation(int output_round, int output_mode, bitset<80> vd_index, bitset<80> v_degree, bitset<80> v_0, bitset<80> k_degree, bitset<80> k_0) {
	T max_degree = v_degree.count();

	//initial
	vector<Vdeg<T>> D(288, Vdeg<T>(1 << vd_index.count())), mul_D(288, Vdeg<T>(1 << vd_index.count())), 
				lin_D(288, Vdeg<T>(1 << vd_index.count())), three_D(288, Vdeg<T>(1 << vd_index.count()));
	
	trivium_default_initial_vector_degree<T>(D, v_degree, k_degree, v_0, k_0, vd_index);
	for (int i = 1; i <= output_round; i++)
	{
		//cout << i << endl;
		trivium_vector_degree_update<T>(i, D, mul_D, lin_D, three_D);	
	}
	return(trivium_output_z<T>(D, output_mode, max_degree));
}




