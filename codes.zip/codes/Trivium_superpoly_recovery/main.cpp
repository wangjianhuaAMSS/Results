#include "main.h"




//int main(int argc, char const* argv[]) {
int main() {
	clock_t start, end;
	start = clock();
	srand((int)time(0));
	int cube_i = -1;
	int cube_n;
	int target_round;
	int threadNumber;
	bitset<80> cube;


	//for (int i = 0; i < argc; i++) {
	//	if (!strcmp(argv[i], "-i")) cube_i = atoi(argv[i + 1]);
	//	if (!strcmp(argv[i], "-r")) target_round = atoi(argv[i + 1]);
    //	if (!strcmp(argv[i], "-t")) threadNumber = atoi(argv[i + 1]);
	//}
	cube_i = 7;
	target_round = 838;
    threadNumber = 8;

	if (cube_i == 1) {
		int cube_index[37] = { 2, 4, 6, 8, 10, 12, 14, 17, 19, 21, 23, 25, 27, 29, 32, 34, 36, 38, 40, 42, 44, 47, 49, 51, 53, 55, 57, 59, 62, 64, 66, 68, 70, 72, 74, 77, 79};
		cube_n = 37;
		for (int i = 0; i < cube_n; i++) {
			cube[cube_index[i]] = 1;
		}
	}
	else if (cube_i == 2) {
		int cube_index[39] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 15, 19, 21, 24, 26, 28, 30, 34, 36, 39, 41, 45, 47, 49, 51, 54, 58, 60, 62, 64, 66, 69, 71, 73, 75, 77, 79 };
		cube_n = 39;
		for (int i = 0; i < cube_n; i++) {
			cube[cube_index[i]] = 1;
		}
	}
	else if (cube_i == 3) {
		int cube_index[38] = {0, 1, 2, 4, 6, 8, 10, 12, 15, 17, 19, 21, 23, 25, 27, 30, 32, 34, 36, 38, 40, 42, 45, 47, 49, 51, 53, 55, 57, 60, 62, 64, 66, 68, 70, 72, 75, 79 
	};
		cube_n = 38;
		for (int i = 0; i < cube_n; i++) {
			cube[cube_index[i]] = 1;
		}
	}
	else if (cube_i == 4) {
		int cube_index[36] = {0,1,2,4,6,8,11,13,15,17,19,21,23,26,27,28,29,32,34, 36, 38,39, 41,42,45,47,48,50,52,53,57,69,71,75,76,79};
		cube_n = 36;
		for (int i = 0; i < cube_n; i++) {
			cube[cube_index[i]] = 1;
		}
	}
	else if (cube_i == 5) {
		int cube_index[57] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 38, 40, 42, 45, 47, 49, 51, 53, 55, 57, 60, 62, 64, 66, 68, 70, 72, 77, 75, 79};
		cube_n = 57;
		for (int i = 0; i < cube_n; i++) {
			cube[cube_index[i]] = 1;
		}
	}
	else if (cube_i == 6) {
		int cube_index[40] = {0, 1, 2, 4, 6, 8, 9, 11, 13, 15, 17, 19, 21, 24, 26, 28, 30, 32, 34, 36, 39, 41, 43, 45, 47, 49, 51, 54, 56, 58, 60, 62, 64, 66, 69, 71, 73, 75, 77, 79};
		cube_n = 40;
		for (int i = 0; i < cube_n; i++) {
			cube[cube_index[i]] = 1;
		}
	}
	else if (cube_i == 7) {
		int cube_index[38] = {0, 1, 2, 4, 7, 10, 11, 12, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 36, 38, 40, 42, 44, 46, 48, 51, 53, 55, 57, 59, 61, 63, 66, 68, 70, 72, 76, 78 };
		cube_n = 38;
		for (int i = 0; i < cube_n; i++) {
			cube[cube_index[i]] = 1;
		}
	}
	else {
		cout << "Please input again!" << endl;
		return(1);
	}
	
	
	
	vector<int> divround, target;
	KVpoly spoly;
	ofstream spolyFile;
	string str = "spoly" + to_string(cube_i) + "_" + to_string(target_round) + ".txt";
	spolyFile.open(str.c_str());
	
	divround.push_back(target_round);
	divround.push_back(200);


	vector<KVpoly> state0(288),state1(288);
	vector<Kpoly> k_fun;
	trivium_simplify_poly(state0, k_fun, 0);
	trivium_simplify_poly(state1, k_fun, 200);
	target.push_back(65);
	target.push_back(92);
	target.push_back(161);
	target.push_back(176);
	target.push_back(242);
	target.push_back(287);
	if (recovery_superpoly(0, 200, threadNumber, cube, divround, state0, state1, target, spoly) == 1) {
		cout << spoly << endl;
        spolyFile << spoly << endl;
	}
    spolyFile.close();
	end = clock();
	cout << "total running time is " << double(end - start) / CLOCKS_PER_SEC << "sec" << endl;
	return 0;
}
